        <!-- Begin Page Content -->
        <div class="container-fluid">

            <!-- Page Heading -->
            <h1 class="h3 mb-4 text-gray-800"> <i class="fas fa-fw fa-tachometer-alt"></i> <?= $title; ?></h1>


                 <!-- Basic Card Example -->
                 <div class="card shadow mb-4">
                    <div class="card-header py-3">
                       <h6 class="m-0 font-weight-bold text-primary">Dashboard</h6>
                    </div>
                    <div class="card-body">
                    <h3>Selamat datang di halaman utama Sistem Penjualan</h3>
                    <img src="assets/img/barang/bg.jpeg" alt="Girl in a jacket" width="1000" height="300">
                </div>
                </div>

        </div>
        <!-- /.container-fluid -->

        </div>
        <!-- End of Main Content -->